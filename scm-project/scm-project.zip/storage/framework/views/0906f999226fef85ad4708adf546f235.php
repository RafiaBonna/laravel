

<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                
                <div class="invoice p-3 mb-3">
                    
                    
                    <div class="row">
                        <div class="col-12">
                            <h4>
                                <i class="fas fa-sign-out-alt"></i> Raw Material Issue Invoice
                                <small class="float-right">Date: <?php echo e(\Carbon\Carbon::parse($stock->issued_date)->format('d M Y')); ?></small>
                            </h4>
                        </div>
                    </div>

                    
                    <div class="row invoice-info">
                        <div class="col-sm-4 invoice-col">
                            Issued From (Warehouse)
                            <address>
                                <strong>Main Warehouse</strong><br>
                                
                            </address>
                        </div>
                        
                        <div class="col-sm-4 invoice-col">
                            Issued To (Depot)
                            <address>
                                <strong><?php echo e($stock->depot->name ?? 'N/A'); ?></strong><br>
                                
                                
                                
                            </address>
                        </div>
                        
                        <div class="col-sm-4 invoice-col">
                            <b>Invoice #00<?php echo e($stock->id); ?></b><br>
                            <br>
                            <b>Material Name:</b> <?php echo e($stock->rawMaterial->name); ?><br>
                        </div>
                    </div>

                    
                    <div class="row">
                        <div class="col-12 table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Material</th>
                                        <th>Issued Qty</th>
                                        <th>Unit</th>
                                        
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td><?php echo e($stock->rawMaterial->name); ?></td>
                                        <td><?php echo e($stock->issued_quantity); ?></td>
                                        <td><?php echo e($stock->unit); ?></td>
                                        
                                        
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    
                    
                    

                    
                    <div class="row no-print">
                        <div class="col-12">
                            
                            <a href="#" onclick="window.print(); return false;" class="btn btn-default"><i class="fas fa-print"></i> Print</a>
                            
                            
                            <a href="<?php echo e(route('stockout.index')); ?>" class="btn btn-primary float-right" style="margin-right: 5px;">
                                <i class="fas fa-list"></i> Back to List
                            </a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laravel\scm-project\resources\views\pages\stock_out\invoice.blade.php ENDPATH**/ ?>
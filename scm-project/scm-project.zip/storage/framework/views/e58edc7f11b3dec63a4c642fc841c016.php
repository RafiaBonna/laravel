<?php $__env->startSection('content'); ?>
<h3>Receive Raw Material</h3>

<form action="<?php echo e(route('stockin.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label>Raw Material</label>
        <select name="raw_material_id" class="form-control" required>
            <option value="">Select Material</option>
            <?php $__currentLoopData = $rawMaterials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <option value="<?php echo e($material->id); ?>"><?php echo e($material->name); ?> (Stock: <?php echo e($material->current_stock); ?>)</option> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-group">
        <label>Supplier</label>
        <select name="supplier_id" class="form-control" required>
            <option value="">Select Supplier</option>
            <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-group">
        <label>Received Quantity</label>
        <input type="number" step="0.01" name="received_quantity" class="form-control" required>
    </div>

    <div class="form-group">
        <label>Unit Price</label>
        <input type="number" step="0.01" name="unit_price" class="form-control">
    </div>

    <button type="submit" class="btn btn-success">Receive</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laravel\scm-project\resources\views\pages\stock_in\create.blade.php ENDPATH**/ ?>
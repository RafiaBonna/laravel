<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="container-fluid">
        <h1 class="text-center mt-5">Dashboard Content Loaded Successfully!</h1>
        <p class="text-center">Your main content goes here.</p>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laravel\scm-project\resources\views\layouts\content.blade.php ENDPATH**/ ?>
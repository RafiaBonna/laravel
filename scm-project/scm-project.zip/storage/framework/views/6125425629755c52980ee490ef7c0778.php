<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="header pb-5 pt-5 pt-lg-8 d-flex align-items-center"
    style="min-height: 50px; background-image: url(../assets/img/theme/profile-cover.jpg); background-size: cover; background-position: center top;">
    <span class="mask bg-gradient-default opacity-8"></span>
    <div class="container-fluid d-flex align-items-center">
      <div class="row align-items-center">
        <div class="col-lg-12 col-md-10 text-center">
          <h1 class="display-2 text-white text-center">Supplier List</h1>
          <a href="<?php echo e(route('supplier.create')); ?>" class="btn btn-dark">Add Supplier</a>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="container mt-4">
  <div class="table-responsive">
    <table class="table table-striped">
      <thead>
        <tr>
          <th scope="col">ID</th>
          <th scope="col">Name</th>
          <th scope="col">Email</th>
          <th scope="col">Phone</th>
          <th scope="col">Address</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <th scope="row"><?php echo e($loop->iteration); ?></th>
          <td><?php echo e($s->name); ?></td>
          <td><?php echo e($s->email); ?></td>
          <td><?php echo e($s->phone); ?></td>
          <td><?php echo e($s->address); ?></td>
          <td>
            
            <div class="d-flex">
              
              
              <a href="<?php echo e(route('supplier.edit', $s->id)); ?>" 
                 class="btn btn-sm btn-primary" 
                 style="margin-right: 10px;" 
                 title="Edit Supplier: <?php echo e($s->name); ?>">
                 <i class="fas fa-edit"></i> 
              </a>
              
              
              <form action="<?php echo e(route('supplier.delete')); ?>" method="POST"
                onsubmit="return confirm('আপনি কি নিশ্চিত যে আপনি এই সরবরাহকারীকে (<?php echo e($s->name); ?>) মুছে ফেলতে চান?');">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="supplier_id" value="<?php echo e($s->id); ?>">
                <button type="submit" class="btn btn-sm btn-danger"
                  title="Delete Supplier: <?php echo e($s->name); ?>">
                  <i class="fas fa-trash-alt"></i> 
                </button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laravel\scm-project\resources\views\pages\supplier\view.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<h3>Stock Out List (Issued Materials)</h3>


<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<table class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Material</th>
            <th>Destination (Depot)</th>
            <th>Quantity</th>
            <th>Unit</th>
            
            <th>Date</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $stockOuts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($stock->id); ?></td>
            <td><?php echo e($stock->rawMaterial->name); ?></td>
            <td><?php echo e($stock->depot->name ?? 'N/A'); ?></td> 
            <td><?php echo e($stock->issued_quantity); ?></td>
            <td><?php echo e($stock->unit); ?></td>
            
            <td><?php echo e(\Carbon\Carbon::parse($stock->issued_date)->format('d M Y')); ?></td>
            <td>
                
                <a href="<?php echo e(route('stockout.invoice', $stock->id)); ?>" class="btn btn-info btn-sm">View Invoice</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="7" class="text-center">No issued materials found.</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laravel\scm-project\resources\views\pages\stock_out\index.blade.php ENDPATH**/ ?>
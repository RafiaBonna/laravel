<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                
                
                <div class="invoice p-3 mb-3">
                    
                    
                    <div class="row">
                        <div class="col-12">
                            <h4>
                                <i class="fas fa-receipt"></i> Raw Material Receive Invoice
                                <small class="float-right">Date: <?php echo e(\Carbon\Carbon::parse($stock->received_date)->format('d M Y')); ?></small>
                            </h4>
                        </div>
                    </div>

                    
                    <div class="row invoice-info">
                        <div class="col-sm-4 invoice-col">
                            From Supplier
                            <address>
                                <strong><?php echo e($stock->supplier->name); ?></strong><br>
                                
                                
                                
                                Supplier ID: #<?php echo e($stock->supplier_id); ?>

                            </address>
                        </div>
                        <div class="col-sm-4 invoice-col">
                            To Warehouse
                            <address>
                                <strong>SCM Company</strong><br>
                                
                                [Warehouse Address]<br>
                                [Phone/Contact Info]
                            </address>
                        </div>
                        <div class="col-sm-4 invoice-col">
                            <b>Invoice ID #<?php echo e($stock->id); ?></b><br>
                            <b>Material:</b> <?php echo e($stock->rawMaterial->name); ?><br>
                            <b>Received Date:</b> <?php echo e(\Carbon\Carbon::parse($stock->received_date)->format('d/m/Y')); ?>

                        </div>
                    </div>
                    
                    <hr>

                    
                    <div class="row">
                        <div class="col-12 table-responsive">
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th>Material Name</th>
                                    <th>Unit</th>
                                    <th class="text-right">Quantity</th>
                                    <th class="text-right">Unit Price (TK)</th>
                                    <th class="text-right">Subtotal (TK)</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td><?php echo e($stock->rawMaterial->name); ?></td>
                                    <td><?php echo e($stock->unit); ?></td>
                                    <td class="text-right"><?php echo e($stock->received_quantity); ?></td>
                                    <td class="text-right"><?php echo e($stock->unit_price ? number_format($stock->unit_price, 2) : 'N/A'); ?></td>
                                    <td class="text-right">
                                        <?php
                                            $total = $stock->unit_price ? ($stock->received_quantity * $stock->unit_price) : 0;
                                        ?>
                                        <?php if($stock->unit_price): ?>
                                            <?php echo e(number_format($total, 2)); ?>

                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-6">
                            <p class="lead">Notes:</p>
                            <p class="text-muted well well-sm shadow-none" style="margin-top: 10px;">
                                Raw material received and successfully added to inventory.
                            </p>
                        </div>
                        <div class="col-6">
                            <p class="lead">Summary</p>

                            <div class="table-responsive">
                                <table class="table">
                                    <tr>
                                        <th style="width:50%">Subtotal:</th>
                                        <td class="text-right"><?php echo e($stock->unit_price ? number_format($total, 2) . ' TK' : 'N/A'); ?></td>
                                    </tr>
                                    
                                    <tr>
                                        <th>Total:</th>
                                        <td class="text-right"><b><?php echo e($stock->unit_price ? number_format($total, 2) . ' TK' : 'N/A'); ?></b></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>

                    
                    <div class="row no-print">
                        <div class="col-12">
                            
                            <a href="#" onclick="window.print(); return false;" class="btn btn-default"><i class="fas fa-print"></i> Print</a>
                            
                            
                            <a href="<?php echo e(route('stockin.index')); ?>" class="btn btn-primary float-right" style="margin-right: 5px;">
                                <i class="fas fa-list"></i> Back to List
                            </a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laravel\scm-project\resources\views\pages\stock_in\invoice.blade.php ENDPATH**/ ?>
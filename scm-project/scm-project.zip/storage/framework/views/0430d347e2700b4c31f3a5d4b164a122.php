<footer class="main-footer bg-light text-dark text-center py-3">
    <strong>Copyright &copy; 2014-<?php echo e(date('Y')); ?> <a href="https://adminlte.io" class="text-white">AdminLTE.io</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 3.2.0
    </div>
</footer>

<aside class="control-sidebar control-sidebar-dark">
    </aside>


</div> 

<script src="<?php echo e(asset('admin/plugins/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/js/adminlte.js')); ?>"></script>




<?php echo $__env->yieldContent('scripts'); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\laravel\scm-project\resources\views\layouts\footer.blade.php ENDPATH**/ ?>
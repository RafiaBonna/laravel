<?php $__env->startSection('content'); ?>
<h3>Stock In List</h3>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>ID</th>
            <th>Material</th>
            <th>Supplier</th>
            <th>Quantity</th>
            <th>Unit</th>
            <th>Unit Price</th>
            <th>Date</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $stockIns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($stock->id); ?></td>
            <td><?php echo e($stock->rawMaterial->name); ?></td>
            <td><?php echo e($stock->supplier->name); ?></td>
            <td><?php echo e($stock->received_quantity); ?></td>
            <td><?php echo e($stock->unit); ?></td>
            <td><?php echo e($stock->unit_price ?? 'N/A'); ?></td>
            <td><?php echo e($stock->received_date); ?></td>
            <td>
                <a href="<?php echo e(route('stockin.invoice', $stock->id)); ?>" class="btn btn-info btn-sm">View Invoice</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laravel\scm-project\resources\views\pages\stock_in\index.blade.php ENDPATH**/ ?>